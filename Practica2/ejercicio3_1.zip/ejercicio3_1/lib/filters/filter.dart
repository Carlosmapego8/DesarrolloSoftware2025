abstract class Filter {
  String? execute(String value);
}
